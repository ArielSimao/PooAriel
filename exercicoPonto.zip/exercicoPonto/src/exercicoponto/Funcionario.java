/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicoponto;



/**
 *
 * @author aluno
 */
public abstract class Funcionario {
    private int id;
    private String nome;
    private String email;
    private String documento;

     public Funcionario(int id, String nome, String email, String documento){
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.documento = documento;
     }
     
     public void imprimir(){
        System.out.println("Id: " + getId());
        System.out.println("Nome: " + getNome());
        System.out.println("Cidade: " + getEmail());
        System.out.println("Documento: " + getDocumento());
     }
     
     
     
     
     
    /*
    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append("Dados da conta \n");
        sb.append("Id: ").append(id).append("\n");
        sb.append("Nome: ").append(nome).append("\n");
        sb.append("Email: ").append(email).append("\n");
        sb.append("Documento: ").append(documento).append("\n");
        return sb.toString();
    }*/

    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    
    public String getNome() {
        return nome;
    }

    
    public void setNome(String nome) {
        this.nome = nome;
    }

    
    public String getEmail() {
        return email;
    }

    
    public void setEmail(String email) {
        this.email = email;
    }

    
    public String getDocumento() {
        return documento;
    }

    
    public void setDocumento(String documento) {
        this.documento = documento;
    }
}