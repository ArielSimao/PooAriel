
package exercicoponto;


//import java.time.LocalDate;
//import java.time.LocalDateTime;
//import java.time.LocalTime;
//import java.time.Month;
//import java.time.Month;

public class GerenciarControlePontoMain {

    
    public static void main(String[] args) throws InterruptedException {
        
        Gerente gr =  new Gerente(1, "Carlos", "carlos@gmail.com", "12345", "carlos&gr", "12345");
        Operador op = new Operador(2, "Luciana", "luciana@gmail.com", "23456", 10);
        Secretaria sc = new Secretaria(3, "Carol", "carol@gmail.com", "34567", "(xx) xxxx - xxxx", "15");
        
        RegistroPonto rp = new RegistroPonto();
        
        rp.apresentarRegistroPonto(gr);
        rp.apresentarRegistroPonto(op);
        rp.apresentarRegistroPonto(sc);
        
        //LocalDateTime.of(year, Month.MARCH, dayOfMonth, hour, minute, second);   
    }
    
}
