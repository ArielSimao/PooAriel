/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicoponto;

/**
 *
 * @author aluno
 */
public class Operador extends Funcionario {
    
    private double valorHora;
    
    
    public Operador(int id, String nome, String email, String documento, double valorHora) {
        super(id, nome, email, documento);
        
        this.valorHora = valorHora;
    }
    
    public double getValorHora(){
        return valorHora;
    }
    
    public void setValorHora(double valorHora){
        this.valorHora = valorHora;
    }
    
}
